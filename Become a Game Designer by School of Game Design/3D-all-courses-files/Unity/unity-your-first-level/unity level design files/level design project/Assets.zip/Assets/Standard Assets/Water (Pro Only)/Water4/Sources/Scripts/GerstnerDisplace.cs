using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(WaterBase))]

public class GerstnerDisplace : Displace 
{		
		
}