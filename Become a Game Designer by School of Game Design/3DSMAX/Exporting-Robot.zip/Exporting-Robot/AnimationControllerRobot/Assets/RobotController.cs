﻿using UnityEngine;
using System.Collections;

public class RobotController : MonoBehaviour
{
	private Animator myAnimator;

	void Start ()
	{
		myAnimator = GetComponent<Animator> ();
	}

	void Update ()
	{
		if (myAnimator)
		{
			myAnimator.SetFloat ( "speed", Input.GetAxis ( "Vertical" ) );
		}
	}

}
